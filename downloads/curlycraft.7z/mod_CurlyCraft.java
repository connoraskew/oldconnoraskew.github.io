public class mod_CurlyCraft
extends BaseMod {
    public static final yr hamburger = new amm(1000, 12, false).a("Hamburger");
    public static final yr breadslice = new amm(1001, 1, false).a("Bread Slice");
    public static final yr sausagecooked = new amm(1002, 4, true).a("Cooked Sausage");
    public static final yr sausageraw = new amm(1003, 2, false).a("Raw Sausage");
    public static final yr hotdog = new amm(1004, 7, false).a("Hotdog");
    public static final yr cheese = new amm(1005, 1, false).a("Cheese");
    public static final yr cheesetoastie = new amm(1006, 3, false).a("Cheese Toastie");
    public static final yr fishsandwhich = new amm(1007, 7, false).a("Fish Sandwich");
    public static final yr rottensandwich = new amm(1008, 6, false).a(aad.s.H, 30, 1, 0.8f).a("Rotten Sandwich");
    public static final yr doughball = new yr(1009).a("Dough Ball");
    public static final yr plaindoughnut = new amm(1010, 6, false).a("Plain Doughnut");
    public static final yr reddoughnut = new amm(1011, 10, false).a("Red Doughnut");
    public static final yr bluedoughnut = new amm(1012, 10, false).a("Blue Doughnut");
    public static final yr yellowdoughnut = new amm(1013, 10, false).a("Yellow Doughnut");
    public static final yr pinkdoughnut = new amm(1014, 10, false).a("Pink Doughnut");
    public static final yr greendoughnut = new amm(1015, 10, false).a("Green Doughnut");
    public static final yr chickensandwich = new amm(1016, 9, false).a("Chicken Sandwich");
    public static final yr hamsandwich = new amm(1017, 5, false).a("Ham Sandwich");
    public static final yr beer = new amm(1018, 15, true).a(aad.k.H, 15, 1, 0.8f).a("Beer");
    public static final yr cider = new amm(1019, 16, true).a(aad.k.H, 15, 1, 0.8f).a("Cider");
    public static final yr icecream = new amm(1020, 12, false).a("Ice Cream");
    public static final yr redgrape = new amm(1021, 1, false).a("Red Grape");
    public static final yr greengrape = new amm(1022, 1, false).a("Green Grape");
    public static final yr redwine = new amm(1023, 6, false).a(aad.k.H, 15, 1, 0.8f).a("Red Wine");
    public static final yr greenwine = new amm(1024, 6, false).a(aad.k.H, 15, 1, 0.8f).a("Green Wine");

    public mod_CurlyCraft() {
        mod_CurlyCraft.redgrape.bS = ModLoader.addOverride((String)"/gui/items.png", (String)"/CurlyClansFoodMod/redgrapeItem.png");
        ModLoader.addName((Object)icecream, (String)"Ice Cream");
        mod_CurlyCraft.icecream.bS = ModLoader.addOverride((String)"/gui/items.png", (String)"/CurlyClansFoodMod/icecreamItem.png");
        ModLoader.addName((Object)cider, (String)"Cider");
        mod_CurlyCraft.cider.bS = ModLoader.addOverride((String)"/gui/items.png", (String)"/CurlyClansFoodMod/ciderItem.png");
        ModLoader.addName((Object)beer, (String)"Beer");
        mod_CurlyCraft.beer.bS = ModLoader.addOverride((String)"/gui/items.png", (String)"/CurlyClansFoodMod/beerItem.png");
        ModLoader.addName((Object)hamsandwich, (String)"Ham Sandwich");
        mod_CurlyCraft.hamsandwich.bS = ModLoader.addOverride((String)"/gui/items.png", (String)"/CurlyClansFoodMod/hamsandwichItem.png");
        ModLoader.addName((Object)chickensandwich, (String)"Chicken Sandwich");
        mod_CurlyCraft.chickensandwich.bS = ModLoader.addOverride((String)"/gui/items.png", (String)"/CurlyClansFoodMod/chickensandwichItem.png");
        ModLoader.addName((Object)hamburger, (String)"Hamburger");
        mod_CurlyCraft.hamburger.bS = ModLoader.addOverride((String)"/gui/items.png", (String)"/CurlyClansFoodMod/hamburgerItem.png");
        ModLoader.addName((Object)breadslice, (String)"Bread Slice");
        mod_CurlyCraft.breadslice.bS = ModLoader.addOverride((String)"/gui/items.png", (String)"/CurlyClansFoodMod/breadsliceItem.png");
        ModLoader.addName((Object)sausagecooked, (String)"Cooked Sausage");
        mod_CurlyCraft.sausagecooked.bS = ModLoader.addOverride((String)"/gui/items.png", (String)"/CurlyClansFoodMod/sausagecookedItem.png");
        ModLoader.addName((Object)sausageraw, (String)"Raw Sausage");
        mod_CurlyCraft.sausageraw.bS = ModLoader.addOverride((String)"/gui/items.png", (String)"/CurlyClansFoodMod/sausagerawItem.png");
        ModLoader.addName((Object)hotdog, (String)"Hotdog");
        mod_CurlyCraft.hotdog.bS = ModLoader.addOverride((String)"/gui/items.png", (String)"/CurlyClansFoodMod/hotdogItem.png");
        ModLoader.addName((Object)cheese, (String)"Cheese");
        mod_CurlyCraft.cheese.bS = ModLoader.addOverride((String)"/gui/items.png", (String)"/CurlyClansFoodMod/cheeseItem.png");
        ModLoader.addName((Object)cheesetoastie, (String)"Cheese on Toast");
        mod_CurlyCraft.cheesetoastie.bS = ModLoader.addOverride((String)"/gui/items.png", (String)"/CurlyClansFoodMod/cheesetoastieItem.png");
        ModLoader.addName((Object)fishsandwhich, (String)"Fish Sandwich");
        mod_CurlyCraft.fishsandwhich.bS = ModLoader.addOverride((String)"/gui/items.png", (String)"/CurlyClansFoodMod/fishsandwhichItem.png");
        ModLoader.addName((Object)rottensandwich, (String)"Rotten Sandwich");
        mod_CurlyCraft.rottensandwich.bS = ModLoader.addOverride((String)"/gui/items.png", (String)"/CurlyClansFoodMod/rottensandwichItem.png");
        ModLoader.addName((Object)doughball, (String)"Dough Ball");
        mod_CurlyCraft.doughball.bS = ModLoader.addOverride((String)"/gui/items.png", (String)"/CurlyClansFoodMod/doughballItem.png");
        ModLoader.addName((Object)plaindoughnut, (String)"Plain Doughnut");
        mod_CurlyCraft.plaindoughnut.bS = ModLoader.addOverride((String)"/gui/items.png", (String)"/CurlyClansFoodMod/doughnutplainItem.png");
        ModLoader.addName((Object)reddoughnut, (String)"Red Doughnut");
        mod_CurlyCraft.reddoughnut.bS = ModLoader.addOverride((String)"/gui/items.png", (String)"/CurlyClansFoodMod/doughnutredItem.png");
        ModLoader.addName((Object)bluedoughnut, (String)"Blue Doughnut");
        mod_CurlyCraft.bluedoughnut.bS = ModLoader.addOverride((String)"/gui/items.png", (String)"/CurlyClansFoodMod/doughnutblueItem.png");
        ModLoader.addName((Object)yellowdoughnut, (String)"Yellow Doughnut");
        mod_CurlyCraft.yellowdoughnut.bS = ModLoader.addOverride((String)"/gui/items.png", (String)"/CurlyClansFoodMod/doughnutyellowItem.png");
        ModLoader.addName((Object)greendoughnut, (String)"Green Doughnut");
        mod_CurlyCraft.greendoughnut.bS = ModLoader.addOverride((String)"/gui/items.png", (String)"/CurlyClansFoodMod/doughnutgreenItem.png");
        ModLoader.addShapelessRecipe((aan)new aan(sausageraw, 2), (Object[])new Object[]{yr.aq});
        ModLoader.addShapelessRecipe((aan)new aan(icecream, 1), (Object[])new Object[]{yr.E, yr.aG, yr.aY, yr.aD});
        ModLoader.addShapelessRecipe((aan)new aan(cider, 1), (Object[])new Object[]{yr.j, yr.ax, yr.aY, yr.ax});
        ModLoader.addShapelessRecipe((aan)new aan(beer, 1), (Object[])new Object[]{yr.T, yr.ax, yr.aY, yr.ax});
        ModLoader.addShapelessRecipe((aan)new aan(breadslice, 5), (Object[])new Object[]{yr.U});
        ModLoader.addRecipe((aan)new aan(hamsandwich, 1), (Object[])new Object[]{"#", "X", "#", Character.valueOf('#'), breadslice, Character.valueOf('X'), yr.aq});
        ModLoader.addRecipe((aan)new aan(chickensandwich, 1), (Object[])new Object[]{"#", "X", "#", Character.valueOf('#'), breadslice, Character.valueOf('X'), yr.bl});
        ModLoader.addRecipe((aan)new aan(hamburger, 1), (Object[])new Object[]{"#", "X", "#", Character.valueOf('#'), breadslice, Character.valueOf('X'), yr.bj});
        ModLoader.addRecipe((aan)new aan(hotdog, 1), (Object[])new Object[]{"#", "X", "#", Character.valueOf('#'), breadslice, Character.valueOf('X'), sausagecooked});
        ModLoader.addRecipe((aan)new aan(cheesetoastie, 1), (Object[])new Object[]{"X", "#", Character.valueOf('#'), breadslice, Character.valueOf('X'), cheese});
        ModLoader.addRecipe((aan)new aan(cheese, 1), (Object[])new Object[]{"#", Character.valueOf('#'), yr.aG});
        ModLoader.addRecipe((aan)new aan(fishsandwhich, 1), (Object[])new Object[]{"#", "X", "#", Character.valueOf('#'), breadslice, Character.valueOf('X'), yr.aV});
        ModLoader.addRecipe((aan)new aan(rottensandwich, 1), (Object[])new Object[]{"#", "X", "#", Character.valueOf('#'), breadslice, Character.valueOf('X'), yr.bm});
        ModLoader.addRecipe((aan)new aan(doughball, 6), (Object[])new Object[]{"X", "#", Character.valueOf('#'), yr.ax, Character.valueOf('X'), yr.T});
        ModLoader.addRecipe((aan)new aan(plaindoughnut, 1), (Object[])new Object[]{"0X0", "X0X", "0X0", Character.valueOf('#'), yr.ax, Character.valueOf('X'), doughball});
        ModLoader.addSmelting((int)mod_CurlyCraft.sausageraw.bQ, (aan)new aan(sausagecooked, 1));
    }

    public void load() {
    }

    public String getVersion() {
        return "1.2.5";
    }
}