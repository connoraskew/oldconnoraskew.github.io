﻿using UnityEngine;
using System.Collections;

public class Player2D : MonoBehaviour {

    [SerializeField]    private float m_fHealth;
                        private float m_fMaxHealth;
    [SerializeField]    private float m_fSpeed;
    [SerializeField]    private float m_fJumpForce;
                        private int m_iPlayerCoins;
                        private Rigidbody2D pRigidbody2D;
                        private float m_fInputHorizontal;
                        private float m_fInputVertical;
    [SerializeField]    private Transform leftFoot;
    [SerializeField]    private Transform rightFoot;
                        private Vector2 leftFootPosition;
                        private Vector2 rightFootPosition;
                        private RaycastHit2D leftFootRayHit;
                        private RaycastHit2D rightFootRayHit;
    [SerializeField]    private float footRayLength;
    [SerializeField]    private bool isDead;
                        private bool isPunching;
                        private bool isPaused;
                        private bool isFacingRight;
                        private bool isCameraFollow;
                        private Vector2 v2MousePos;
                        private Animator pAnimator;
    [SerializeField]    private GameObject[] doorKeys;
                        private int iKeysCollected;
                        private bool hasCompletedLevel;
                        private GUIStyle guiStyle;
    [SerializeField]    private Font guiFont;

    // Use this for initialization
    void Start()
    {
        Time.timeScale = 1;
        pAnimator = this.transform.GetComponent<Animator>();
        pRigidbody2D = GetComponent<Rigidbody2D>();
        isDead = false;
        isFacingRight = true;
        v2MousePos = new Vector2(0, 0);
        m_fMaxHealth = m_fHealth;
        isCameraFollow = true;
        isPaused = false;
    }

    // Update is called once per frame
    void Update()
    {
        /*Handles pausing gameplay*/
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (isPaused)
                Time.timeScale = 1;
            else
                Time.timeScale = 0;

            isPaused = !isPaused;
        }
        if (hasCompletedLevel)
        {
            Time.timeScale = 0;
        }

        /*
        Player health management
        */
        if (m_fHealth <= 0)
        {
            m_fHealth = 0;
            KillPlayer();
        }
        if (m_fHealth > m_fMaxHealth)
        {
            m_fHealth = m_fMaxHealth;
        }

        /*
        Input Axis
        */
        m_fInputHorizontal = Input.GetAxis("Horizontal");
        m_fInputVertical = Input.GetAxis("Vertical");

        /*
        Handles punching
        */
        isPunching = false;
        if (Input.GetMouseButton(0))
        {
            isPunching = true;
        }

        /*
        Handles mouse world position
        */
        v2MousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);

        /*
        Handles player movement
        */
        GetComponent<Rigidbody2D>().velocity = new Vector2(m_fInputHorizontal * m_fSpeed, GetComponent<Rigidbody2D>().velocity.y);

        /*
        Handles camera positioning
        */
        if (isCameraFollow)
            Camera.main.transform.position = new Vector3(transform.position.x, Camera.main.transform.position.y, Camera.main.transform.position.z);

        /*
        Which direction the player is looking in
        */
        if (!isPaused && !hasCompletedLevel)
        {
            if (v2MousePos.x >= transform.position.x)
            {
                if (!isFacingRight)
                    Flip();
            }
            else if (v2MousePos.x < transform.position.x)
            {
                if (isFacingRight)
                    Flip();
            }
        }
        
        /*
        Handles jumping
        */
        if (m_fInputVertical > 0 && IsGrounded())
        {
            Jump();
        }

        /*
        Handles animation states
        */
        pAnimator.SetFloat("fSpeed", Mathf.Abs(m_fInputHorizontal));
        pAnimator.SetBool("isDead", isDead);
        pAnimator.SetBool("isPunching", isPunching);
    }

    //OnGUI is called once a frame after OnUpdate, draw the GUI here
    void OnGUI()
    {
        /*Fonts!*/
        GUI.skin.font = guiFont;
        /*Draw normal UI if there are doors and keys*/
        if (GameObject.FindWithTag("Door") && GameObject.FindWithTag("Key"))
        {
            GUI.Box(new Rect(0, 0, 200, 75), "");
            GUI.Label(new Rect(10, 10, 200, 40), "Health: " + m_fHealth + "/" + m_fMaxHealth);
            GUI.Label(new Rect(10, 30, 200, 40), "Keys: " + iKeysCollected + " / " + GameObject.FindGameObjectsWithTag("Key").Length);
            GUI.Label(new Rect(10, 50, 200, 40), "Coins: " + m_iPlayerCoins);
        }
        else
        /*Draw normal UI if there are no doors or keys*/
        {
            GUI.Box(new Rect(0, 0, 200, 50), "");
            GUI.Label(new Rect(10, 0, 200, 40), "Health: " + m_fHealth +"/"+ m_fMaxHealth);
            GUI.Label(new Rect(10, 20, 200, 40), "Coins: " + m_iPlayerCoins);
        }

        if (isDead)
        {
            GUI.backgroundColor = Color.red;
            
            if (GUI.Button(new Rect(Screen.width / 2 - 125, Screen.height / 2 - 100, 250, 50), "Try Again"))
            {
                Application.LoadLevel(Application.loadedLevel);
            }
            GUI.Button(new Rect(Screen.width / 2 - 125, Screen.height / 2 - 50, 250, 50), "Level Selection");
            {
            }
            GUI.Button(new Rect(Screen.width / 2 - 125, Screen.height / 2, 250, 50), "Main Menu");
            {
            }
            GUI.Button(new Rect(Screen.width / 2 - 125, Screen.height / 2 + 100, 250, 50), "Quit Game");
            {
            }

            GUI.backgroundColor = Color.white;
        }
        if (isPaused && !hasCompletedLevel)
        {
            /*Draw other menu screens UIs*/
            GUI.backgroundColor = Color.black;
            if (GUI.Button(new Rect(Screen.width / 2 - 125, Screen.height / 2 - 150, 250, 50), "Resume"))
            {
                Application.LoadLevel(Application.loadedLevel);
            }
            if (GUI.Button(new Rect(Screen.width / 2 - 125, Screen.height / 2 - 100, 250, 50), "Restart Level"))
            {
                Application.LoadLevel(Application.loadedLevel);
            }
            GUI.Button(new Rect(Screen.width / 2 - 125, Screen.height / 2 - 50, 250, 50), "Level Selection");
            {
            }
            GUI.Button(new Rect(Screen.width / 2 - 125, Screen.height / 2, 250, 50), "Main Menu");
            {
            }
            GUI.Button(new Rect(Screen.width / 2 - 125, Screen.height / 2 + 50, 250, 50), "Quit Game");
            {
            }

            GUI.backgroundColor = Color.white;
        }
        if (hasCompletedLevel)
        {
            /*Draw other menu screens UIs*/
            GUI.backgroundColor = Color.black;

            if (GUI.Button(new Rect(Screen.width / 2 - 125, Screen.height / 2 - 100, 250, 50), "Restart Level"))
            {
                Application.LoadLevel(Application.loadedLevel);
            }
            GUI.Button(new Rect(Screen.width / 2 - 125, Screen.height / 2 - 50, 250, 50), "Level Selection");
            {
            }
            GUI.Button(new Rect(Screen.width / 2 - 125, Screen.height / 2, 250, 50), "Main Menu");
            {
            }
            GUI.Button(new Rect(Screen.width / 2 - 125, Screen.height / 2 + 50, 250, 50), "Quit Game");
            {
            }

            GUI.backgroundColor = Color.white;
        }
    }

    void OnDrawGizmos()
    {
        IsGrounded();
        Gizmos.DrawLine(leftFootPosition, new Vector2(leftFootPosition.x, leftFootPosition.y - footRayLength));
        Gizmos.DrawLine(rightFootPosition, new Vector2(rightFootPosition.x, rightFootPosition.y - footRayLength));
        Gizmos.DrawWireCube(transform.position, GetComponent<BoxCollider2D>().bounds.size);
    }

    public bool IsGrounded()
    {
        /*
        Foot Rays and isGrounded method

        DEBUGGING:
        If it's not working, set layers to ignore raycasting!
        */
        leftFootPosition = leftFoot.position;
        leftFootRayHit = Physics2D.Raycast(leftFootPosition, Vector2.down, footRayLength);

        rightFootPosition = rightFoot.position;
        rightFootRayHit = Physics2D.Raycast(rightFootPosition, Vector2.down, footRayLength);

        if (leftFootRayHit)
        {
            if (leftFootRayHit.collider.tag != "Player")
            {
                return true;
            }
            else
            {
                Debug.Log(leftFootRayHit.collider.name + " is stopping me from jumping!");
                return false;
            }
        }
        if (rightFootRayHit)
        {
            if (rightFootRayHit.collider.tag != "Player")
            {
                return true;
            }
            else
            {
                Debug.Log(leftFootRayHit.collider.name + " is stopping me from jumping!");
                return false;
            }
        }
        else
        {
            return false;
        }
    }

    public void Flip()
    {
        isFacingRight = !isFacingRight;
        Vector3 theScale = transform.localScale;
        theScale.x *= -1;
        transform.localScale = theScale;
    }

    public float GetInputHorizontal()
    {
        return m_fInputHorizontal;
    }

    public float GetInputVertical()
    {
        return m_fInputVertical;
    }

    public void KillPlayer()
    {
        isDead = true;
        StartCoroutine(IEKillPlayer());
    }

    public void Jump()
    {
        Vector2 v2 = pRigidbody2D.velocity;
        v2.y = m_fJumpForce;
        pRigidbody2D.velocity = v2;
    }

    public float GetHealth()
    {
        return m_fHealth;
    }

    public void SetHealth(float a_fHealth)
    {
        m_fHealth = a_fHealth;
    }

    public int GetCoins()
    {
        return m_iPlayerCoins;
    }

    public void SetCoins(int coins)
    {
        m_iPlayerCoins = coins;
    }

    public void AddCoins(int coins)
    {
        m_iPlayerCoins += coins;
    }

    public void MinusCoins(int coins)
    {
        m_iPlayerCoins -= coins;
    }

    public void SetCameraFollow(bool b)
    {
        isCameraFollow = b;
    }

    public bool GetCameraFollow()
    {
        return isCameraFollow;
    }

    IEnumerator IEKillPlayer()
    {
        isDead = true;
        yield return new WaitForSeconds(2.0f);
        Time.timeScale = 0;
    }

    public void PickupKey(GameObject key)
    {
        for (int i = 0; i < doorKeys.Length; i++)
        {
            if(doorKeys[i] == null)
            {
                doorKeys[i] = key;
                Debug.Log("Player picked up a key");
                i = 9001;
                key.GetComponent<SpriteRenderer>().enabled = false;
                key.GetComponent<BoxCollider2D>().enabled = false;
                iKeysCollected++;
            }
        }
    }
    
    public GameObject[] GetKeys()
    {
        return doorKeys;
    }

    public void DamagePlayer(float damage)
    {
        SetHealth(GetHealth() - damage);
    }

    public void LevelCompleted()
    {
        hasCompletedLevel = true;
    }
}