﻿using UnityEngine;
using System.Xml;
using System.Collections;

public class SaveData {
    private static string path;
    private static int iLevelsCompleted = 25;

    public static void SetPath(string s)
    {
        path = s;
    }
    public static string GetPath()
    {
        return path;
    }
    public static int GetLevelsCompleted()
    {
        /*
        path = "Saves/DANIEL_savedata.xml";

        System.IO.StringReader stringReader = new System.IO.StringReader(path);
        stringReader.Read(); // skip BOM
        System.Xml.XmlReader reader = System.Xml.XmlReader.Create(stringReader);

        Debug.Log(reader.Read().ToString() + "\t" + stringReader.ToString());
        */
        return iLevelsCompleted;
    }
}
