﻿using UnityEngine;
using System.Collections;

public class NavigationMenus : MonoBehaviour {

    [SerializeField]
    private Font menuFont;
    private string stringEntered;
    private string charEntered;
    string acceptedChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    bool mainMenu;
    bool newGameMenu;
    bool loadGameMenu;
    Color menuColour;
    string foundExistingFile;

    void Start()
    {
        stringEntered = "";
        foundExistingFile = "";
        mainMenu = true;
        newGameMenu = false;
        loadGameMenu = false;
        menuColour = Color.black;
    }

    void Update()
    {
        if (newGameMenu)
        {
            if (Input.GetKeyDown(KeyCode.Backspace))
            {
                stringEntered = stringEntered.Remove(stringEntered.Length - 1);
            }
            if (Input.anyKeyDown && stringEntered.Length < 10)
            {
                if (acceptedChars.Contains(Input.inputString))
                {
                    charEntered = Input.inputString.ToUpper();
                    stringEntered = stringEntered + "" + charEntered;
                }
            }
        }
    }

    void OnGUI()
    {
        GUI.skin.font = menuFont;

        if (mainMenu)
            MainMenu();
        if (newGameMenu)
            NewGameMenu();
        if (loadGameMenu)
            LoadGameMenu();
    }

    void MainMenu()
    {
        GUI.backgroundColor = menuColour;
        if (GUI.Button(new Rect(Screen.width / 2 - Screen.width / 6, Screen.height / 2 - Screen.height / 7, Screen.width / 3, Screen.height / 8), "New Game"))
        {
            mainMenu = false;
            newGameMenu = true;
        }
        if (GUI.Button(new Rect(Screen.width / 2 - Screen.width / 6, Screen.height / 2, Screen.width / 3, Screen.height / 8), "Load Game"))
        {
            mainMenu = false;
            loadGameMenu = true;
        }
        if (GUI.Button(new Rect(Screen.width / 2 - Screen.width / 6, Screen.height / 2 + Screen.height / 7, Screen.width / 3, Screen.height / 8), "Quit Game"))
        {
            Application.Quit();
        }
    }

    void NewGameMenu()
    {
        stringEntered = stringEntered.ToUpper().Trim();
        GUI.backgroundColor = menuColour;
        GUI.Label(new Rect(Screen.width / 2 - 300, Screen.height / 2 - Screen.height / 4, 10000, 1000), "Enter Save Name: ");
        GUI.Label(new Rect((Screen.width / 2) - (stringEntered.Length * 22), Screen.height / 2 - Screen.height / 10, 100000000, 256), stringEntered);
        if (foundExistingFile != "")
            GUI.Label(new Rect(Screen.width / 2 - 600, 0, 10000, 1000), foundExistingFile + "_savedata.xml already exists!");
        if (GUI.Button(new Rect(Screen.width / 2 - 522, Screen.height / 2 + Screen.height / 6, 512, 128), "Back"))
        {
            newGameMenu = false;
            mainMenu = true;
        }
        if (GUI.Button(new Rect(Screen.width / 2 + 10, Screen.height / 2 + Screen.height / 6, 512, 128), "Accept"))
        {
            if (stringEntered.Trim() != "")
            {
                System.Xml.XmlWriterSettings savedata = new System.Xml.XmlWriterSettings();
                bool doesFileExist = false;
                string path = "Saves/";
                System.IO.DirectoryInfo info = new System.IO.DirectoryInfo(path);
                System.IO.FileInfo[] fileInfo = info.GetFiles();
                foreach (System.IO.FileInfo file in fileInfo)
                {
                    string s = file.ToString().Substring(file.ToString().LastIndexOf("Saves"));
                    if (s.Contains(stringEntered.ToUpper().Trim()))
                    {
                        doesFileExist = true;
                    }
                    print(s);
                }
                if (!doesFileExist)
                {
                    using (System.Xml.XmlWriter writer = System.Xml.XmlWriter.Create("Saves/" + stringEntered + "_savedata.xml", savedata))
                    {
                        writer.WriteAttributeString("LevelsCompleted", "");
                        writer.WriteAttributeString("Coins", "");
                        SaveData.SetPath("Saves/" + stringEntered + "_savedata");
                        savedata.CloseOutput = true;
                        Application.LoadLevel("worldselectionmenu");
                    }
                }
                if (doesFileExist)
                {
                    //System.IO.File.OpenWrite("Saves/" + stringEntered + "_savedata.txt");
                    foundExistingFile = stringEntered;
                    Debug.Log(foundExistingFile + " already exists!");
                }
            }
        }
    }

    void LoadGameMenu()
    {
        string path = "Saves/";
        System.IO.DirectoryInfo info = new System.IO.DirectoryInfo(path);
        System.IO.FileInfo[] fileInfo = info.GetFiles();
        GUI.backgroundColor = menuColour;
        for (int i = 0; i < fileInfo.Length; i++)
        {
            string saveName = fileInfo[i].ToString();
            saveName = saveName.ToUpper();
            saveName = saveName.Remove(0, saveName.LastIndexOf("\\")+1);
            saveName = saveName.Remove(saveName.LastIndexOf("_"));
            if (GUI.Button(new Rect(Screen.width / 2 - Screen.width / 6, 0 + Screen.height / 10 + i * Screen.height / 12 - i, Screen.width / 3, Screen.height / 12), saveName))
            {
                SaveData.SetPath("Saves/" + saveName + "_savedata.xml");
                Application.LoadLevel("worldselectionmenu");
            }
        }
        if (GUI.Button(new Rect(Screen.width / 2 - 256, Screen.height / 2 + Screen.height / 6, 512, 128), "Back"))
        {
            loadGameMenu = false;
            mainMenu = true;
        }
    }
}
