﻿using UnityEngine;
using System.Collections;

public class EnemyAI2D : MonoBehaviour {
    
    [SerializeField]
    private enum ColourOfBoxes
    {
        White, Red, Yellow, Blue, Cyan, Magenta, Green
    }
    [Header("Select The Colour of the Gizmos (not shown in game)")]
    [SerializeField]
    private ColourOfBoxes colorSelected;
    [Header("Enemy Health")]
    [SerializeField]
    private float m_fHealth;
    [Header("Enemy Speed")]
    [SerializeField]
    private float m_fSpeed;
    [Header("Enemy Attack Damage")]
    [SerializeField]
    private float m_fAttackDamage;
    [Header("Enemy Attack Range")]
    [SerializeField]
    private float m_fAttackRange;
    [Header("Enemy Attack Cooldown")]
    [SerializeField]
    private float m_fAttackCooldown;    
    BoxCollider2D[] detectionColliderArray;
    BoxCollider2D detectionCollider;
    BoxCollider2D enemyCollider;
    [Header("waypoint game objects into the correct order.")]
    [Header("Set amount of waypoints then drag 'n' drop the")]
    [SerializeField]
    private GameObject[] waypoints;
    [SerializeField]
    private int currentWaypoint;
    private bool isFollowingPlayer;
    private GameObject player;
    private bool canAttack;

    // Use this for initialization
    void Start ()
    {
        enemyCollider = GetComponent<BoxCollider2D>();
        detectionColliderArray = GetComponentsInChildren<BoxCollider2D>();
        foreach (BoxCollider2D detectCol in detectionColliderArray)
        {
            if (detectCol.tag != "Enemy")
            {
                detectionCollider = detectCol;
            }
        }
        currentWaypoint = 0;
        player = GameObject.FindWithTag("Player");
        canAttack = true;
    }
	
	// Update is called once per frame
	void Update ()
    {
        if (!isFollowingPlayer)
        {
            if (waypoints.Length != 0)
            {
                if (transform.position.x < waypoints[currentWaypoint].transform.position.x)
                {
                    transform.Translate(Vector2.right * Time.deltaTime * m_fSpeed);
                    if (transform.position.x >= waypoints[currentWaypoint].transform.position.x)
                    {
                        IncrementWaypoint();
                    }
                }
                else if (transform.position.x > waypoints[currentWaypoint].transform.position.x)
                {
                    transform.Translate(Vector2.left * Time.deltaTime * m_fSpeed);
                    if (transform.position.x <= waypoints[currentWaypoint].transform.position.x)
                    {
                        IncrementWaypoint();
                    }
                }
            } 
        }
        else if (isFollowingPlayer)
        {
            if (player.transform.position.x > transform.position.x)
            {
                transform.Translate(Vector2.right * Time.deltaTime * m_fSpeed);
            }
            else if (player.transform.position.x + 0.1f < transform.position.x)
            {
                transform.Translate(Vector2.left * Time.deltaTime * m_fSpeed);
            }
        }
        if (canAttack)
        {
            if (Mathf.Abs(player.transform.position.x - transform.position.x) < m_fAttackRange && Mathf.Abs(player.transform.position.y - transform.position.y) < m_fAttackRange)
            {
                player.GetComponent<Player2D>().DamagePlayer(m_fAttackDamage);
            }
            canAttack = false;
            StartCoroutine(AttackCooldown());
        }
    }

    IEnumerator AttackCooldown()
    {
        yield return new WaitForSeconds(m_fAttackCooldown);
        canAttack = true;
    }

    void IncrementWaypoint()
    {
        if (currentWaypoint == waypoints.Length - 1)
        {
            currentWaypoint = 0;
        }
        else
        {
            currentWaypoint++;
        }
    }

    public void EnteredDetectionTrigger(GameObject obj)
    {
        if (obj.tag == "Player")
        {
            SetFollowPlayer(true);
        }
    }

    public void ExitedDetectionTrigger(GameObject obj)
    {
        if (obj.tag == "Player")
        {
            SetFollowPlayer(false);
        }
    }

    void SetFollowPlayer(bool b)
    {
        isFollowingPlayer = b;
    }

    void OnDrawGizmos()
    {
        enemyCollider = GetComponent<BoxCollider2D>();
        detectionColliderArray = GetComponentsInChildren<BoxCollider2D>();
        foreach (BoxCollider2D detectCol in detectionColliderArray)
        {
            if (detectCol.tag != "Enemy")
            {
                detectionCollider = detectCol;
            }
        }
        if (colorSelected.Equals(ColourOfBoxes.White))
        {
            Gizmos.color = Color.white;
        }
        if (colorSelected.Equals(ColourOfBoxes.Red))
        {
            Gizmos.color = Color.red;
        }
        if (colorSelected.Equals(ColourOfBoxes.Green))
        {
            Gizmos.color = Color.green;
        }
        if (colorSelected.Equals(ColourOfBoxes.Blue))
        {
            Gizmos.color = Color.blue;
        }
        if (colorSelected.Equals(ColourOfBoxes.Yellow))
        {
            Gizmos.color = Color.yellow;
        }
        if (colorSelected.Equals(ColourOfBoxes.Cyan))
        {
            Gizmos.color = Color.cyan;
        }
        if (colorSelected.Equals(ColourOfBoxes.Magenta))
        {
            Gizmos.color = Color.magenta;
        }
        Gizmos.DrawWireCube(transform.position, enemyCollider.bounds.size);
        Gizmos.DrawWireCube(detectionCollider.transform.position, detectionCollider.bounds.size);
        if (isFollowingPlayer)
        {
            Gizmos.DrawSphere(new Vector2(transform.position.x, transform.position.y + 1), 0.1f);
        }
        foreach(GameObject waypoint in waypoints)
        {
            Gizmos.DrawWireSphere(waypoint.transform.position, 0.05f);
        }
    }
}