﻿using UnityEngine;
using System.Collections;

public class Door : MonoBehaviour
{

    [SerializeField]
    private GameObject[] keysNeeded;
    private Player2D player;
    private int iKeysRequired;

    void Start()
    {
        player = GameObject.FindWithTag("Player").GetComponent<Player2D>();
    }

    void OnTriggerEnter2D()
    {
        iKeysRequired = keysNeeded.Length;

        for (int i = 0; i < keysNeeded.Length; i++)
        {
            Key keyNeededScript = keysNeeded[i].GetComponent<Key>();
            foreach (GameObject key in player.GetKeys())
            {
                if(key != null)
                {
                    Key KeyScript = key.GetComponent<Key>();
                    if (KeyScript.GetID() == keyNeededScript.GetID())
                    {
                        iKeysRequired--;
                        break;
                    }
                }
            }
        }
        if (iKeysRequired == 0)
        {
            Debug.Log("Player Has All Keys!");
            player.LevelCompleted();
        }

        if (iKeysRequired != 0)
        {
            Debug.Log("Player doesn't have all the keys ("+iKeysRequired+" needed!)");
        }
    }
}
