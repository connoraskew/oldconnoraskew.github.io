﻿using UnityEngine;
using System.Collections;

public class EnemyAI2DDetection : MonoBehaviour {

    void OnTriggerEnter2D(Collider2D col)
    {
        if (GetComponentInParent<EnemyAI2D>())
        {
            GetComponentInParent<EnemyAI2D>().EnteredDetectionTrigger(col.gameObject);
        }
    }

    void OnTriggerExit2D(Collider2D col)
    {
        if (GetComponentInParent<EnemyAI2D>())
        {
            GetComponentInParent<EnemyAI2D>().ExitedDetectionTrigger(col.gameObject);
        }
    }
}
