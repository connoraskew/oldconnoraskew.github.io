﻿using UnityEngine;
using System.Collections;

public class Key : MonoBehaviour {

    [SerializeField]
    private int keyID;

    void OnTriggerEnter2D()
    {
        GameObject.FindGameObjectWithTag("Player").GetComponent<Player2D>().PickupKey(gameObject);
    }
    public int GetID()
    {
        return keyID;
    }
}