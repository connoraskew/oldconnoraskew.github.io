﻿using UnityEngine;
using System.Collections;

public class WorldSelectionMenu : MonoBehaviour {

    [SerializeField]
    private int numberOfLevels;
    [SerializeField]
    private Font menuFont;
    private Color menuColour;
    private Color defaultMenuColour;
    Vector2 scrollPosition;

    // Use this for initialization
    void Start ()
    {
        scrollPosition = Vector2.zero;
        defaultMenuColour = GUI.color;
    }
	
	// Update is called once per frame
	void Update () {
	
	}

    void OnGUI()
    {
        GUI.color = defaultMenuColour;
        GUI.skin.font = menuFont;

        scrollPosition = GUI.BeginScrollView(new Rect(Screen.width / 2 - 528 / 2, 0, 528, Screen.height), scrollPosition,
            new Rect(Screen.width / 2 - 256, 0, 512, 128 * numberOfLevels), false, true);
        for (int i = 0; i < numberOfLevels; i++)
        {
            if (i == SaveData.GetLevelsCompleted())
            {
                menuColour = Color.grey;
                GUI.color = menuColour;
            }
            if (GUI.Button(new Rect(Screen.width / 2 - 256, i * 128, 512, 128), "Level " + i))
            {
                if (i < SaveData.GetLevelsCompleted())
                    Application.LoadLevel("level" + i);
            }
        }
        GUI.EndScrollView();
    }
}
