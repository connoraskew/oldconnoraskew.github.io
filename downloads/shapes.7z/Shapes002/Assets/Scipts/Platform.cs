﻿using UnityEngine;
using System.Collections;

public class Platform : MonoBehaviour
{
    /*
    HOW TO USE PLATFORM SCRIPT
    Drag in 1 platform prefab and at least two waypoint prefabs.
    Set the array of waypoints on the platform to desired number.
    Drag the waypoint gameobjects into the platform waypoints array.
    Set the color of the waypoints and platform in color.
    */
    [SerializeField]
    private enum ColourOfBoxes
    {
        White, Red, Yellow, Blue, Cyan, Magenta, Green
    }
    [Header("Select The Colour of the Gizmos (not shown in game)")]
    [SerializeField]
    private ColourOfBoxes colorSelected;

    [Header("Set amount of waypoints then drag 'n' drop the")]
    [Header("waypoint game objects into the correct order.")]
    [Header("")]
    [SerializeField]
    private GameObject[] waypoints;
    
    private int currentWaypoint = 0;
    
    [Header("The speed that the platform moves")]
    [SerializeField]
    private float platformSpeed;

    void Update ()
    {
	    if (transform.position.x == waypoints[currentWaypoint].transform.position.x && transform.position.y == waypoints[currentWaypoint].transform.position.y)
        {
            incrementWaypoint();
        }
        else
        {
            if (waypoints[currentWaypoint].GetComponent<PlatformWaypoint>().GetMoveToThisWaypoint() == "diagonal" || waypoints[currentWaypoint].GetComponent<PlatformWaypoint>().GetMoveToThisWaypoint() == "diag" || waypoints[currentWaypoint].GetComponent<PlatformWaypoint>().GetMoveToThisWaypoint() == "xy" || waypoints[currentWaypoint].GetComponent<PlatformWaypoint>().GetMoveToThisWaypoint() == "yx")
            {
                transform.position = Vector3.MoveTowards(transform.position, waypoints[currentWaypoint].transform.position, Time.deltaTime * platformSpeed);
            }
            if (waypoints[currentWaypoint].GetComponent<PlatformWaypoint>().GetMoveToThisWaypoint() == "x")
            {
                if (transform.position.x == waypoints[currentWaypoint].transform.position.x)
                {
                    incrementWaypoint();
                }
                else
                {
                    transform.position = Vector3.MoveTowards(transform.position, new Vector3(waypoints[currentWaypoint].transform.position.x, transform.position.y, transform.position.z), Time.deltaTime * platformSpeed);
                }
            }
            if (waypoints[currentWaypoint].GetComponent<PlatformWaypoint>().GetMoveToThisWaypoint() == "y")
            {
                if (transform.position.y == waypoints[currentWaypoint].transform.position.y)
                {
                    incrementWaypoint();
                }
                else
                {
                    transform.position = Vector3.MoveTowards(transform.position, new Vector3(transform.position.x, waypoints[currentWaypoint].transform.position.y, transform.position.z), Time.deltaTime * platformSpeed);
                }
            }
        }
	}

    void incrementWaypoint()
    {
        if (currentWaypoint == waypoints.Length - 1)
        {
            currentWaypoint = 0;
        }
        else
        {
            currentWaypoint++;
        }
    }

    void OnDrawGizmos()
    {
        if (colorSelected.Equals(ColourOfBoxes.White))
        {
            Gizmos.color = Color.white;
        }
        if (colorSelected.Equals(ColourOfBoxes.Red))
        {
            Gizmos.color = Color.red;
        }
        if (colorSelected.Equals(ColourOfBoxes.Green))
        {
            Gizmos.color = Color.green;
        }
        if (colorSelected.Equals(ColourOfBoxes.Blue))
        {
            Gizmos.color = Color.blue;
        }
        if (colorSelected.Equals(ColourOfBoxes.Yellow))
        {
            Gizmos.color = Color.yellow;
        }
        if (colorSelected.Equals(ColourOfBoxes.Cyan))
        {
            Gizmos.color = Color.cyan;
        }
        if (colorSelected.Equals(ColourOfBoxes.Magenta))
        {
            Gizmos.color = Color.magenta;
        }
        Gizmos.DrawWireCube(transform.position, GetComponent<Collider2D>().bounds.size);
        foreach (GameObject waypoint in waypoints)
        {
            if (waypoint)
            {
                Gizmos.DrawWireSphere(waypoint.transform.position, 0.1f);
            }
        }
    }
}
