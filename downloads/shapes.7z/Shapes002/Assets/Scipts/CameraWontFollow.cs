﻿using UnityEngine;
using System.Collections;

public class CameraWontFollow : MonoBehaviour {
    
    void OnTriggerEnter2D()
    {
        GameObject.FindWithTag("Player").GetComponent<Player2D>().SetCameraFollow(false);
    }

    void OnTriggerExit2D()
    {
        GameObject.FindWithTag("Player").GetComponent<Player2D>().SetCameraFollow(true);
    }
}