﻿using UnityEngine;
using System.Collections;

public class Coin : MonoBehaviour {

    [SerializeField]
    private int coinAmount;

    void OnTriggerEnter2D(Collider2D col)
    {
        if (col.gameObject.tag == "Player")
        {
            GameObject.FindWithTag("Player").GetComponent<Player2D>().AddCoins(coinAmount);
            Destroy(gameObject);
            Debug.Log("Player picked up a coin");
        }
    }

    void OnDrawGizmos()
    {
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, gameObject.GetComponent<Collider2D>().bounds.size.x / 2);
    }

}