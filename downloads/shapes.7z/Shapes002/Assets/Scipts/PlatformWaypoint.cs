﻿using UnityEngine;
using System.Collections;

public class PlatformWaypoint : MonoBehaviour {

    private enum waypointMovement
    {
        Diagonal, Horizontal, Vertical
    }

    [SerializeField]
    private waypointMovement moveToThisWaypoint;

    public string GetMoveToThisWaypoint()
    {
        if (moveToThisWaypoint.Equals(waypointMovement.Diagonal))
            return "xy";
        if (moveToThisWaypoint.Equals(waypointMovement.Horizontal))
            return "x";
        if (moveToThisWaypoint.Equals(waypointMovement.Vertical))
            return "y";
        else
            return "Something went wrong on " + gameObject.name;
    }
}
