﻿using UnityEngine;
using System.Collections;

public class WallCollider : MonoBehaviour {

    private BoxCollider2D edgy;

	void OnDrawGizmos()
    {
        edgy = GetComponent<BoxCollider2D>();
        Gizmos.color = Color.green;
        Gizmos.DrawWireCube(transform.position, edgy.bounds.size);
    }
}
